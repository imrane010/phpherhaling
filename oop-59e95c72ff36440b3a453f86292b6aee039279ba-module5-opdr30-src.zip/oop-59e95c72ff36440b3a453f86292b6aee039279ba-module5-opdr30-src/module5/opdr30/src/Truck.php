<?php

namespace Opdr30;

class Truck extends Vehicle
{
    private $loadCapacity;

    public function __construct($brand, $model, $year, array $color, $loadCapacity)
    {
        parent::__construct($brand, $model, $year, $color);
        $this->loadCapacity = $loadCapacity;
    }

    public function getLoadCapacity()
    {
        return $this->loadCapacity;
    }

    public function setLoadCapacity($loadCapacity)
    {
        $this->loadCapacity = $loadCapacity;
    }

    public function getFuelType(): string
    {
        return "Diesel";
    }

    public function printVehicleInfo(): void
    {
        echo "Vrachtwagen: " . $this->getBrand() . " " . $this->getModel() . ", Kleur: " . $this->getColor() . ", Jaar: " . $this->getYear() . ", Laadcapaciteit: " . $this->getLoadCapacity() . " kg, Brandstoftype: " . $this->getFuelType() . "<br>";
    }
}