<?php

namespace Opdr30;

class ElectricCar extends Car
{
    private $batteryCapacity;

    public function __construct(string $brand, string $model, string $year, array $color, float $batteryCapacity)
    {
        parent::__construct($brand, $model, $year, $color);
        $this->batteryCapacity = $batteryCapacity;
    }

    public function getFuelType(): string
    {
        return "Elektrisch";
    }

    public function calculateMileage(): float
    {
        return $this->batteryCapacity * 5;
    }

    public function printVehicleInfo()
    {
        echo "Auto: " . $this->getBrand() . " " . $this->getModel() . ", Kleur: " . $this->getColor() . ", Brandstoftype: " . $this->getFuelType() . ", Mileage: " . $this->calculateMileage() . " km<br>";
    }
}