<?php

namespace Opdr30;

class Motorcycle extends Vehicle
{
    private $offRoad;

    public function __construct($brand, $model, $year, $color, $offRoad)
    {
        parent::__construct($brand, $model, $year, $color);
        $this->offRoad = $offRoad;
    }

    public function isOffRoad()
    {
        return $this->offRoad;
    }

    public function setOffRoad($offRoad)
    {
        $this->offRoad = $offRoad;
    }

    public function getFuelType(): string
    {
        return "Benzine";
    }

    public function printVehicleInfo(): void
    {
        echo "Motor: " . $this->getBrand() . " " . $this->getModel() . ", Kleur: " . $this->getColor() . ", Jaar: " . $this->getYear() . ", Brandstoftype: " . $this->getFuelType() . ", Off-road: " . ($this->isOffRoad() ? "Ja" : "Nee") . "<br>";
    }

}