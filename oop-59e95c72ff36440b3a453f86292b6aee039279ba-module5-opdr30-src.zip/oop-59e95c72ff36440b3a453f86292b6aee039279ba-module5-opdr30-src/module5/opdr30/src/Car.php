<?php

namespace Opdr30;

abstract class Car extends Vehicle
{
    public function __construct(string $brand, string $model, string $year, array $color)
    {
        parent::__construct($brand, $model, $year, $color);
    }

    abstract public function getFuelType(): string;

    abstract public function calculateMileage(): float;
}