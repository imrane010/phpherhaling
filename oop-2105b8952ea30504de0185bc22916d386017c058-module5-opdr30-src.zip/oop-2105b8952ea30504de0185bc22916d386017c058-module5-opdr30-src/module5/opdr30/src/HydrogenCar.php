<?php

namespace Opdr30;

class HydrogenCar extends Car
{
    private float $fuelCellSize;

    public function __construct(string $brand, string $model, string $year, array $color, float $fuelCellSize)
    {
        parent::__construct($brand, $model, $year, $color);
        $this->fuelCellSize = $fuelCellSize;
    }

    public function getFuelType(): string
    {
        return "Waterstof";
    }

    public function calculateMileage(): float
    {
        return $this->fuelCellSize * 15;
    }

    public function printVehicleInfo()
    {
        echo "Hydrogen Car: {$this->getBrand()} {$this->getModel()}, Kleur: {$this->getColor()}, Mileage: {$this->calculateMileage()} km<br>";
    }
}
