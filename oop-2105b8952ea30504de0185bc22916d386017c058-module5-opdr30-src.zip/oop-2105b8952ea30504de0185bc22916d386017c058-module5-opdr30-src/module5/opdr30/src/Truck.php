<?php

namespace Opdr30;

class Truck extends Vehicle
{
    private int $loadCapacity;

    public function __construct(string $brand, string $model, string $year, array $color, int $loadCapacity)
    {
        parent::__construct($brand, $model, $year, $color);
        $this->loadCapacity = $loadCapacity;
    }

    public function getLoadCapacity()
    {
        return $this->loadCapacity;
    }

    public function printVehicleInfo()
    {
        echo "Truck: {$this->getBrand()} {$this->getModel()}, Kleur: {$this->getColor()}, Laadcapaciteit: {$this->getLoadCapacity()} kg<br>";
    }
}
