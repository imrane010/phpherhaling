<?php

namespace Opdr30;

class VehicleList
{
    private array $vehicles = [];

    public function addVehicle(Vehicle $vehicle)
    {
        $this->vehicles[] = $vehicle;
    }

    public function getAllVehicles(): array
    {
        return $this->vehicles;
    }
}
