<?php

namespace Opdr30;

class ElectricCar extends Car
{
    private float $batteryCapacity;

    public function __construct(string $brand, string $model, string $year, array $color, float $batteryCapacity)
    {
        parent::__construct($brand, $model, $year, $color);
        $this->batteryCapacity = $batteryCapacity;
    }

    public function getFuelType(): string
    {
        return "Elektrisch";
    }

    public function calculateMileage(): float
    {
        return $this->batteryCapacity * 5;
    }

    public function printVehicleInfo()
    {
        echo "Electric Car: {$this->getBrand()} {$this->getModel()}, Kleur: {$this->getColor()}, Mileage: {$this->calculateMileage()} km<br>";
    }
}
