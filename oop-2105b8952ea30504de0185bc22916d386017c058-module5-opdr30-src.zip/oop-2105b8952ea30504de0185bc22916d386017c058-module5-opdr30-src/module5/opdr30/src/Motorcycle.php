<?php

namespace Opdr30;

class Motorcycle extends Vehicle
{
    private bool $offRoad;

    public function __construct(string $brand, string $model, string $year, array $color, bool $offRoad)
    {
        parent::__construct($brand, $model, $year, $color);
        $this->offRoad = $offRoad;
    }

    public function isOffRoad()
    {
        return $this->offRoad;
    }

    public function printVehicleInfo()
    {
        echo "Motorcycle: {$this->getBrand()} {$this->getModel()}, Kleur: {$this->getColor()}, Off-road: " . ($this->offRoad ? "Ja" : "Nee") . "<br>";
    }
}
