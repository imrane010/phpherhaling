<?php

namespace Opdr30;

class Truck extends Vehicle
{
    private $loadCapacity;

    public function __construct(string $brand, string $model, string $year, array $color, int $loadCapacity)
    {
        parent::__construct($brand, $model, $year, $color);
        $this->loadCapacity = $loadCapacity;
    }

    public function getLoadCapacity()
    {
        return $this->loadCapacity;
    }

    public function setLoadCapacity($loadCapacity)
    {
        $this->loadCapacity = $loadCapacity;
    }

    public function printVehicleInfo()
    {
        echo "Vrachtwagen: " . $this->getBrand() . " " . $this->getModel() . ", Kleur: " . $this->getColor() . ", Laadcapaciteit: " . $this->getLoadCapacity() . " kg<br>";
    }

    public function getFuelType(): string
    {
        return "Diesel";
    }

    public function calculateMileage(): float
    {
        return 200;
    }
}
