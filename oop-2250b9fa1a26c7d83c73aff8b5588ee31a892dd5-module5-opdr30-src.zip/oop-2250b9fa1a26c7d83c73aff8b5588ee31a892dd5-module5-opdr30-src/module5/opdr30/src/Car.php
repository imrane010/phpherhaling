<?php

namespace Opdr30;

class Car extends Vehicle
{
    public function __construct(string $brand, string $model, string $year, array $color)
    {
        parent::__construct($brand, $model, $year, $color);
    }

    public function printVehicleInfo()
    {
        echo "Auto: " . $this->getBrand() . " " . $this->getModel() . ", Kleur: " . $this->getColor() . "<br>";
    }

    public function getFuelType(): string
    {
        return "Benzine";
    }

    public function calculateMileage(): float
    {
        return 150;
    }
}
