<?php

namespace Opdr30;

class HydrogenCar extends Car
{
    private $fuelCellSize;

    public function __construct(string $brand, string $model, string $year, array $color, float $fuelCellSize)
    {
        parent::__construct($brand, $model, $year, $color);
        $this->fuelCellSize = $fuelCellSize;
    }

    public function getFuelType(): string
    {
        return "Waterstof";
    }

    public function calculateMileage(): float
    {
        return $this->fuelCellSize * 8;
    }

    public function printVehicleInfo()
    {
        echo "Auto: " . $this->getBrand() . " " . $this->getModel() . ", Kleur: " . $this->getColor() . ", Brandstoftype: " . $this->getFuelType() . ", Mileage: " . $this->calculateMileage() . " km<br>";
    }
}
