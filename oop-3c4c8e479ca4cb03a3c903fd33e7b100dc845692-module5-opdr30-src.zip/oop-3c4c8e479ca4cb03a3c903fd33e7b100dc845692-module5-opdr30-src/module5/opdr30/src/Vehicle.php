<?php

namespace Opdr30;

abstract class Vehicle
{
    protected string $brand;
    protected string $model;
    protected string $year;
    protected array $color;
    public static array $allVehicles = [];

    public function __construct(string $brand, string $model, string $year, array $color)
    {
        $this->brand = $brand;
        $this->model = $model;
        $this->year = $year;
        $this->color = $color;
        self::$allVehicles[] = $this;
    }

    public function getBrand()
    {
        return $this->brand;
    }

    public function getModel()
    {
        return $this->model;
    }

    public function getYear()
    {
        return $this->year;
    }

    public function getColor()
    {
        return implode(", ", $this->color);
    }

    public static function getAllVehicles()
    {
        return self::$allVehicles;
    }

    abstract public function printVehicleInfo();
}
