<?php

namespace Opdr30;

class GasolineCar extends Car
{
    private float $engineSize;

    public function __construct(string $brand, string $model, string $year, array $color, float $engineSize)
    {
        parent::__construct($brand, $model, $year, $color);
        $this->engineSize = $engineSize;
    }

    public function getFuelType(): string
    {
        return "Benzine";
    }

    public function calculateMileage(): float
    {
        return $this->engineSize * 10;
    }

    public function printVehicleInfo()
    {
        echo "Gasoline Car: {$this->getBrand()} {$this->getModel()}, Kleur: {$this->getColor()}, Mileage: {$this->calculateMileage()} km<br>";
    }
}
